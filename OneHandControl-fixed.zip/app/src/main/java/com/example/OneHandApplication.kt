package com.example

import android.app.Application
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.ViewModelStore
import androidx.lifecycle.ViewModelStoreOwner
import com.example.viewmodel.OneHandViewModel

/** Holds ONE ViewModel for the whole process so the app screen and the overlay show the same state. */
class OneHandApplication : Application(), ViewModelStoreOwner {
    override val viewModelStore: ViewModelStore = ViewModelStore()

    val viewModel: OneHandViewModel by lazy {
        ViewModelProvider(this, ViewModelProvider.AndroidViewModelFactory.getInstance(this))[OneHandViewModel::class.java]
    }
}
