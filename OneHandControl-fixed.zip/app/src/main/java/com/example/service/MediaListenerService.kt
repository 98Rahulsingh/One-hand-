package com.example.service

import android.service.notification.NotificationListenerService

/** Enabling this gives the app access to active media sessions (used by the media player next). */
class MediaListenerService : NotificationListenerService()
