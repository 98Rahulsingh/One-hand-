package com.example.system

import com.example.model.AudioOutputDevice
import android.media.AudioDeviceInfo
import kotlin.math.roundToInt
import android.app.ActivityOptions
import android.bluetooth.BluetoothAdapter
import android.content.Context
import android.content.Intent
import android.graphics.Rect
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.wifi.WifiManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.accessibilityservice.AccessibilityService
import com.example.service.PanelAccessibilityService

data class ActionResult(val message: String, val newState: Boolean? = null, val needs: String? = null)

/** Real quick-setting actions. Anything Android blocks reports it instead of pretending. */
class QuickActions(private val ctx: Context, private val perms: PermissionsManager, private val shell: ShellRunner) {
    private val cr get() = ctx.contentResolver
    private val cm = ctx.getSystemService(Context.CAMERA_SERVICE) as CameraManager
    private var torchOn = false
    var onTorchChanged: ((Boolean) -> Unit)? = null

    init {
        try {
            cm.registerTorchCallback(object : CameraManager.TorchCallback() {
                override fun onTorchModeChanged(cameraId: String, enabled: Boolean) {
                    torchOn = enabled
                    onTorchChanged?.invoke(enabled)
                }
            }, Handler(Looper.getMainLooper()))
        } catch (_: Exception) {}
    }

    private fun torchId(): String? = cm.cameraIdList.firstOrNull {
        cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
    }

    @Suppress("DEPRECATION")
    fun currentStates(): Map<String, Boolean> {
        val audio = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val wifi = ctx.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
        return mapOf(
            "torch" to torchOn,
            "rotate" to (Settings.System.getInt(cr, Settings.System.ACCELEROMETER_ROTATION, 0) == 1),
            "darkmode" to (Settings.Secure.getInt(cr, "ui_night_mode", 1) == 2),
            "battery_saver" to (Settings.Global.getInt(cr, "low_power", 0) == 1),
            "wifi" to wifi.isWifiEnabled,
            "bluetooth" to (BluetoothAdapter.getDefaultAdapter()?.isEnabled == true),
            "airplane" to (Settings.Global.getInt(cr, Settings.Global.AIRPLANE_MODE_ON, 0) == 1),
            "mute" to (audio.ringerMode == AudioManager.RINGER_MODE_NORMAL),
            "floating" to perms.isFreeformOn(),
            "data" to (Settings.Global.getInt(cr, "mobile_data", 1) == 1)
        )
    }

    private val audioMgr get() = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager

    fun volumePercent(): Float {
        val max = audioMgr.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1)
        return audioMgr.getStreamVolume(AudioManager.STREAM_MUSIC) * 100f / max
    }

    fun setVolumePercent(p: Float) {
        try {
            val max = audioMgr.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
            audioMgr.setStreamVolume(AudioManager.STREAM_MUSIC, (p / 100f * max).roundToInt().coerceIn(0, max), 0)
        } catch (_: Exception) {}
    }

    fun brightnessPercent(): Float = Settings.System.getInt(cr, Settings.System.SCREEN_BRIGHTNESS, 128) * 100f / 255f

    /** Returns false when "Modify system settings" is not allowed yet. */
    fun setBrightnessPercent(p: Float): Boolean {
        if (!perms.canWriteSettings()) return false
        Settings.System.putInt(cr, Settings.System.SCREEN_BRIGHTNESS_MODE, Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL)
        Settings.System.putInt(cr, Settings.System.SCREEN_BRIGHTNESS, (p / 100f * 255f).roundToInt().coerceIn(1, 255))
        return true
    }

    fun outputDevices(): List<AudioOutputDevice> {
        val kinds = setOf(
            AudioDeviceInfo.TYPE_BUILTIN_SPEAKER, AudioDeviceInfo.TYPE_WIRED_HEADPHONES, AudioDeviceInfo.TYPE_WIRED_HEADSET,
            AudioDeviceInfo.TYPE_BLUETOOTH_A2DP, AudioDeviceInfo.TYPE_BLUETOOTH_SCO, AudioDeviceInfo.TYPE_USB_HEADSET,
            AudioDeviceInfo.TYPE_USB_DEVICE, AudioDeviceInfo.TYPE_HDMI
        )
        val devs = audioMgr.getDevices(AudioManager.GET_DEVICES_OUTPUTS).filter { it.type in kinds }
        val inUse = devs.firstOrNull { it.type != AudioDeviceInfo.TYPE_BUILTIN_SPEAKER } ?: devs.firstOrNull()
        return devs.map {
            val builtin = it.type == AudioDeviceInfo.TYPE_BUILTIN_SPEAKER
            val bt = it.type == AudioDeviceInfo.TYPE_BLUETOOTH_A2DP || it.type == AudioDeviceInfo.TYPE_BLUETOOTH_SCO
            AudioOutputDevice(
                it.id.toString(),
                if (builtin) "Phone Speaker" else it.productName.toString(),
                if (bt) "Bluetooth" else if (builtin) "Internal Audio" else "Connected",
                it.id == inUse?.id,
                if (it.type == AudioDeviceInfo.TYPE_HDMI) "tv" else if (builtin) "speaker" else "headphones"
            )
        }
    }

    fun perform(id: String): ActionResult = try {
        when (id) {
            "torch" -> torch()
            "rotate" -> rotate()
            "darkmode" -> secureFlip("Dark mode", "ui_night_mode", off = 1, on = 2, global = false)
            "battery_saver" -> secureFlip("Battery saver", "low_power", off = 0, on = 1, global = true)
            "mute" -> mute()
            "wifi" -> wifi()
            "bluetooth" -> bluetooth()
            "airplane" -> airplane()
            "data" -> mobileData()
            "hotspot" -> panelFallback("hotspot")
            "split" -> global(AccessibilityService.GLOBAL_ACTION_TOGGLE_SPLIT_SCREEN, "Split screen")
            "prev_app" -> previousApp()
            "floating" -> floating()
            "lock" -> if (Build.VERSION.SDK_INT >= 28) global(AccessibilityService.GLOBAL_ACTION_LOCK_SCREEN, "Lock screen") else ActionResult("Needs Android 9 or newer")
            "screenshot" -> if (Build.VERSION.SDK_INT >= 28) global(AccessibilityService.GLOBAL_ACTION_TAKE_SCREENSHOT, "Screenshot") else ActionResult("Needs Android 9 or newer")
            "notifications" -> global(AccessibilityService.GLOBAL_ACTION_NOTIFICATIONS, "Notifications")
            "home" -> global(AccessibilityService.GLOBAL_ACTION_HOME, "Home")
            "back" -> global(AccessibilityService.GLOBAL_ACTION_BACK, "Back")
            "power" -> global(AccessibilityService.GLOBAL_ACTION_POWER_DIALOG, "Power menu")
            else -> ActionResult("Not supported yet")
        }
    } catch (e: SecurityException) {
        ActionResult("Android blocked this: ${e.message}")
    } catch (e: Exception) {
        ActionResult("Could not do that: ${e.message}")
    }

    private fun torch(): ActionResult {
        val id = torchId() ?: return ActionResult("No flashlight on this phone")
        val want = !torchOn
        cm.setTorchMode(id, want)
        torchOn = want
        return ActionResult("Flashlight ${if (want) "ON" else "OFF"}", want)
    }

    private fun rotate(): ActionResult {
        if (!perms.canWriteSettings()) return ActionResult("Allow 'Modify system settings' first", null, "write_settings")
        val on = Settings.System.getInt(cr, Settings.System.ACCELEROMETER_ROTATION, 0) == 1
        Settings.System.putInt(cr, Settings.System.ACCELEROMETER_ROTATION, if (on) 0 else 1)
        return ActionResult("Auto-rotate ${if (on) "OFF" else "ON"}", !on)
    }

    private fun secureFlip(name: String, key: String, off: Int, on: Int, global: Boolean): ActionResult {
        if (!perms.hasSecureSettings()) return ActionResult("$name needs the one-time setup", null, "system_control")
        val isOn = if (global) Settings.Global.getInt(cr, key, off) == on else Settings.Secure.getInt(cr, key, off) == on
        val target = if (isOn) off else on
        if (global) Settings.Global.putInt(cr, key, target) else Settings.Secure.putInt(cr, key, target)
        return ActionResult("$name ${if (isOn) "OFF" else "ON"}", !isOn)
    }

    private fun mute(): ActionResult {
        val audio = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val normal = audio.ringerMode == AudioManager.RINGER_MODE_NORMAL
        audio.ringerMode = if (normal) AudioManager.RINGER_MODE_VIBRATE else AudioManager.RINGER_MODE_NORMAL
        return ActionResult(if (normal) "Vibrate mode" else "Sound ON", !normal)
    }

    private fun direct(cmd: String, name: String, newState: Boolean): ActionResult? =
        if (shell.run(cmd) != null) ActionResult("$name ${if (newState) "ON" else "OFF"}", newState) else null

    @Suppress("DEPRECATION")
    private fun wifi(): ActionResult {
        val wm = ctx.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
        val want = !wm.isWifiEnabled
        direct("svc wifi ${if (want) "enable" else "disable"}", "Wi-Fi", want)?.let { return it }
        if (Build.VERSION.SDK_INT < 29 && wm.setWifiEnabled(want)) {
            return ActionResult("Wi-Fi ${if (want) "ON" else "OFF"}", want)
        }
        return panelFallback("wifi")
    }

    @Suppress("DEPRECATION", "MissingPermission")
    private fun bluetooth(): ActionResult {
        val bt = BluetoothAdapter.getDefaultAdapter() ?: return ActionResult("No Bluetooth on this phone")
        val want = !bt.isEnabled
        direct("svc bluetooth ${if (want) "enable" else "disable"}", "Bluetooth", want)?.let { return it }
        if (Build.VERSION.SDK_INT < 33) {
            val ok = if (bt.isEnabled) bt.disable() else bt.enable()
            if (ok) return ActionResult("Bluetooth ${if (want) "ON" else "OFF"}", want)
        }
        return panelFallback("bluetooth")
    }

    private fun mobileData(): ActionResult {
        val on = Settings.Global.getInt(cr, "mobile_data", 1) == 1
        direct("svc data ${if (on) "disable" else "enable"}", "Mobile data", !on)?.let { return it }
        return panelFallback("data")
    }

    private fun airplane(): ActionResult {
        val on = Settings.Global.getInt(cr, Settings.Global.AIRPLANE_MODE_ON, 0) == 1
        direct("cmd connectivity airplane-mode ${if (on) "disable" else "enable"}", "Airplane mode", !on)?.let { return it }
        return panelFallback("airplane")
    }

    /** Wi-Fi, Bluetooth, airplane, data and hotspot cannot be switched by normal apps on Android 10+. */
    private fun panelFallback(id: String): ActionResult {
        val action = when (id) {
            "wifi", "data", "airplane" ->
                if (Build.VERSION.SDK_INT >= 29) Settings.Panel.ACTION_INTERNET_CONNECTIVITY else Settings.ACTION_WIRELESS_SETTINGS
            "bluetooth" -> Settings.ACTION_BLUETOOTH_SETTINGS
            else -> Settings.ACTION_WIRELESS_SETTINGS
        }
        ctx.startActivity(Intent(action).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        return ActionResult("Turn on Shizuku in Permissions for one-tap switching. Opened the system panel for now")
    }

    private fun global(action: Int, name: String): ActionResult {
        if (!perms.isAccessibilityOn() || PanelAccessibilityService.instance == null)
            return ActionResult("$name needs Accessibility", null, "accessibility")
        return ActionResult(if (PanelAccessibilityService.global(action)) name else "$name failed")
    }

    private fun previousApp(): ActionResult {
        if (!perms.isAccessibilityOn() || PanelAccessibilityService.instance == null)
            return ActionResult("Previous app needs Accessibility", null, "accessibility")
        PanelAccessibilityService.global(AccessibilityService.GLOBAL_ACTION_RECENTS)
        Handler(Looper.getMainLooper()).postDelayed({
            PanelAccessibilityService.global(AccessibilityService.GLOBAL_ACTION_RECENTS)
        }, 350)
        return ActionResult("Switching to previous app")
    }

    private fun floating(): ActionResult {
        if (!perms.hasSecureSettings()) return ActionResult("Floating apps need the one-time setup", null, "freeform")
        val want = !perms.isFreeformOn()
        perms.setInPlace("freeform", want)
        return ActionResult("Floating windows ${if (want) "ON" else "OFF"} (restart the phone once to apply)", want)
    }

    /** Opens an installed app. With Shizuku it opens in a floating window. */
    fun launch(pkg: String): Boolean {
        val intent = ctx.packageManager.getLaunchIntentForPackage(pkg) ?: return false
        val comp = intent.component?.flattenToShortString()
        if (comp != null && shell.isReady()) {
            val out = shell.run("am start --windowingMode 5 -n $comp")
            if (out != null && !out.contains("Error", ignoreCase = true) && !out.contains("Exception", ignoreCase = true)) return true
        }
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        val opts = ActivityOptions.makeBasic()
        if (perms.isFreeformOn()) {
            val dm = ctx.resources.displayMetrics
            val w = (dm.widthPixels * 0.9).toInt()
            val h = (dm.heightPixels * 0.6).toInt()
            val l = (dm.widthPixels - w) / 2
            val t = (dm.heightPixels - h) / 2
            opts.setLaunchBounds(Rect(l, t, l + w, t + h))
            try { // 5 = WINDOWING_MODE_FREEFORM (hidden API, may be blocked on some phones)
                ActivityOptions::class.java.getMethod("setLaunchWindowingMode", Int::class.javaPrimitiveType).invoke(opts, 5)
            } catch (_: Throwable) {}
        }
        ctx.startActivity(intent, opts.toBundle())
        return true
    }
}
