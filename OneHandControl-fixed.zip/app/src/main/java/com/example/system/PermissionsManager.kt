package com.example.system

import android.app.AppOpsManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.PowerManager
import android.os.Process
import android.provider.Settings
import androidx.core.app.NotificationManagerCompat
import com.example.service.MediaListenerService
import com.example.service.PanelAccessibilityService

/** Reads the REAL state of every permission and switches the ones Android allows in place. */
class PermissionsManager(private val ctx: Context) {
    private val cr get() = ctx.contentResolver
    private val a11y = ComponentName(ctx, PanelAccessibilityService::class.java)
    private val listener = ComponentName(ctx, MediaListenerService::class.java)
    private val listenersKey = "enabled_notification_listeners"

    // ---- real state ----
    fun hasSecureSettings() =
        ctx.checkSelfPermission("android.permission.WRITE_SECURE_SETTINGS") == PackageManager.PERMISSION_GRANTED

    private fun enabledList(key: String): List<String> =
        (Settings.Secure.getString(cr, key) ?: "").split(':').filter { it.isNotBlank() }

    fun isAccessibilityOn() = enabledList(Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES)
        .any { ComponentName.unflattenFromString(it) == a11y }

    fun isListenerOn() = enabledList(listenersKey).any { ComponentName.unflattenFromString(it) == listener }

    fun notificationsAllowed() = NotificationManagerCompat.from(ctx).areNotificationsEnabled()

    fun hasUsageAccess(): Boolean {
        val ops = ctx.getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
        @Suppress("DEPRECATION")
        val mode = if (Build.VERSION.SDK_INT >= 29) {
            ops.unsafeCheckOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), ctx.packageName)
        } else {
            ops.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), ctx.packageName)
        }
        return mode == AppOpsManager.MODE_ALLOWED
    }

    fun canDrawOverlay() = Settings.canDrawOverlays(ctx)
    fun canWriteSettings() = Settings.System.canWrite(ctx)
    fun isBatteryExempt() =
        (ctx.getSystemService(Context.POWER_SERVICE) as PowerManager).isIgnoringBatteryOptimizations(ctx.packageName)

    fun isFreeformOn() =
        Settings.Global.getInt(cr, "enable_freeform_support", 0) == 1 &&
            Settings.Global.getInt(cr, "force_resizable_activities", 0) == 1

    // ---- in-place switching (needs WRITE_SECURE_SETTINGS, granted once) ----
    private fun setComponent(key: String, c: ComponentName, on: Boolean) {
        val list = enabledList(key).filterNot { ComponentName.unflattenFromString(it) == c }.toMutableList()
        if (on) list.add(c.flattenToString())
        Settings.Secure.putString(cr, key, list.joinToString(":"))
        if (key == Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) {
            Settings.Secure.putInt(cr, Settings.Secure.ACCESSIBILITY_ENABLED, if (list.isEmpty()) 0 else 1)
        }
    }

    /** Returns true if the switch was flipped right here, false if Android needs another route. */
    fun setInPlace(type: String, on: Boolean): Boolean {
        if (!hasSecureSettings()) return false
        return try {
            when (type) {
                "accessibility" -> setComponent(Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES, a11y, on)
                "media_controls" -> setComponent(listenersKey, listener, on)
                "freeform" -> {
                    val v = if (on) 1 else 0
                    Settings.Global.putInt(cr, "enable_freeform_support", v)
                    Settings.Global.putInt(cr, "force_resizable_activities", v)
                }
                else -> return false
            }
            true
        } catch (e: SecurityException) {
            false
        }
    }

    // ---- fallback screens and guide text ----
    fun systemScreen(type: String): Intent? {
        val uri = Uri.parse("package:${ctx.packageName}")
        val i = when (type) {
            "accessibility" -> Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)
            "media_controls" -> Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)
            "usage_access" -> Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)
            "floating_window" -> Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, uri)
            "write_settings" -> Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, uri)
            "battery_optimization" -> Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, uri)
            "notifications" -> Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS)
                .putExtra(Settings.EXTRA_APP_PACKAGE, ctx.packageName)
            "freeform" -> Intent(Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS)
            else -> return null
        }
        return i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    }

    fun setupCommands(): String {
        val p = ctx.packageName
        return "adb shell pm grant $p android.permission.WRITE_SECURE_SETTINGS\n" +
            "adb shell pm grant $p android.permission.POST_NOTIFICATIONS\n" +
            "adb shell appops set $p GET_USAGE_STATS allow\n" +
            "adb shell appops set $p SYSTEM_ALERT_WINDOW allow\n" +
            "adb shell appops set $p WRITE_SETTINGS allow\n" +
            "adb shell dumpsys deviceidle whitelist +$p"
    }

    fun setupGuide(): String =
        "One-time setup. Connect the phone to a PC (USB debugging or Wireless debugging) and run:\n\n" +
            setupCommands() +
            "\n\n(POST_NOTIFICATIONS is Android 13+ only; an error on older phones is fine.)\n\n" +
            "After this, Accessibility, Media access and Floating apps switch right here with no redirect, " +
            "and every other permission shows its real status."

    fun title(type: String) = when (type) {
        "accessibility" -> "Accessibility"
        "media_controls" -> "Media controls"
        "notifications" -> "Notifications"
        "usage_access" -> "Usage access"
        "floating_window" -> "Floating window permission"
        "freeform" -> "Floating apps (freeform windows)"
        "write_settings" -> "Modify system settings"
        "shizuku" -> "Run actions directly (Shizuku)"
        "battery_optimization" -> "Battery optimization"
        else -> "System controls"
    }

    fun guideText(type: String): String =
        if (type == "shizuku") {
            "1. Install the Shizuku app (Play Store or GitHub).
" +
                "2. Open Shizuku and tap 'Start via Wireless debugging'.
" +
                "3. Come back here, turn this switch on and tap Allow in the popup.

" +
                "After this Wi-Fi, Bluetooth, Mobile data, Airplane mode and floating windows switch in one tap."
        } else {
            "Android does not allow this switch to be flipped from inside the app until the one-time setup is done.

" + setupGuide()
        }
}
