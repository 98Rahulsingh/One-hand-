package com.example.system

import android.content.ComponentName
import android.content.Context
import android.media.AudioDeviceInfo
import android.media.AudioManager
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.os.Build
import android.os.SystemClock
import android.view.KeyEvent
import com.example.model.AudioOutputDevice
import com.example.model.MediaStreamItem
import com.example.service.MediaListenerService

/** Talks to the real players (YouTube, Spotify, ...) through Android media sessions. */
class MediaBridge(private val ctx: Context, private val perms: PermissionsManager) {
    private val msm = ctx.getSystemService(Context.MEDIA_SESSION_SERVICE) as MediaSessionManager
    private val audio = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
    private val listener = ComponentName(ctx, MediaListenerService::class.java)
    private var selectedPkg: String? = null

    data class Now(
        val title: String,
        val artist: String,
        val positionMs: Long,
        val durationMs: Long,
        val playing: Boolean,
        val speed: Float,
        val streams: List<MediaStreamItem>
    )

    private fun controllers(): List<MediaController> {
        if (!perms.isListenerOn()) return emptyList()
        return try { msm.getActiveSessions(listener) } catch (e: SecurityException) { emptyList() }
    }

    private fun pick(list: List<MediaController>): MediaController? =
        list.firstOrNull { it.packageName == selectedPkg }
            ?: list.firstOrNull { it.playbackState?.state == PlaybackState.STATE_PLAYING }
            ?: list.firstOrNull()

    private fun positionOf(c: MediaController): Long {
        val st = c.playbackState ?: return 0L
        if (st.state != PlaybackState.STATE_PLAYING) return st.position
        val delta = SystemClock.elapsedRealtime() - st.lastPositionUpdateTime
        return st.position + (delta * st.playbackSpeed).toLong()
    }

    private fun durationOf(c: MediaController): Long = c.metadata?.getLong(MediaMetadata.METADATA_KEY_DURATION) ?: 0L

    private fun fmt(ms: Long): String {
        val s = (ms / 1000).toInt()
        return if (s <= 0) "--:--" else "%d:%02d".format(s / 60, s % 60)
    }

    private fun label(pkg: String): String = try {
        ctx.packageManager.getApplicationLabel(ctx.packageManager.getApplicationInfo(pkg, 0)).toString()
    } catch (e: Exception) { pkg }

    fun now(): Now {
        val list = controllers()
        val a = pick(list)
        val streams = list.map { c ->
            val d = durationOf(c)
            MediaStreamItem(
                id = c.packageName,
                appName = label(c.packageName),
                trackTitle = c.metadata?.getString(MediaMetadata.METADATA_KEY_TITLE) ?: "Unknown",
                artist = c.metadata?.getString(MediaMetadata.METADATA_KEY_ARTIST) ?: "",
                durationText = fmt(d),
                isActive = c == a,
                iconName = "music",
                progress = if (d > 0) (positionOf(c).toFloat() / d).coerceIn(0f, 1f) else 0f
            )
        }
        if (a == null) {
            val msg = if (perms.isListenerOn()) "Start music or a video in any app" else "Turn on Media access to control players"
            return Now("Nothing playing", msg, 0L, 0L, false, 1f, streams)
        }
        val title = a.metadata?.getString(MediaMetadata.METADATA_KEY_TITLE) ?: "Unknown track"
        val artist = a.metadata?.getString(MediaMetadata.METADATA_KEY_ARTIST) ?: label(a.packageName)
        return Now(
            title, artist, positionOf(a), durationOf(a),
            a.playbackState?.state == PlaybackState.STATE_PLAYING,
            a.playbackState?.playbackSpeed ?: 1f, streams
        )
    }

    private fun key(code: Int) {
        audio.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, code))
        audio.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, code))
    }

    fun playPause() {
        val a = pick(controllers())
        if (a != null) {
            if (a.playbackState?.state == PlaybackState.STATE_PLAYING) a.transportControls.pause() else a.transportControls.play()
        } else key(KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE)
    }

    fun next() {
        val a = pick(controllers())
        if (a != null) a.transportControls.skipToNext() else key(KeyEvent.KEYCODE_MEDIA_NEXT)
    }

    fun previous() {
        val a = pick(controllers())
        if (a != null) a.transportControls.skipToPrevious() else key(KeyEvent.KEYCODE_MEDIA_PREVIOUS)
    }

    fun seekTo(ms: Long): Boolean {
        val a = pick(controllers()) ?: return false
        a.transportControls.seekTo(ms.coerceAtLeast(0L))
        return true
    }

    fun skipBy(deltaMs: Long): Boolean {
        val a = pick(controllers()) ?: return false
        val d = durationOf(a)
        val target = positionOf(a) + deltaMs
        a.transportControls.seekTo(if (d > 0) target.coerceIn(0L, d) else target.coerceAtLeast(0L))
        return true
    }

    fun setSpeed(speed: Float) {
        if (Build.VERSION.SDK_INT >= 29) pick(controllers())?.transportControls?.setPlaybackSpeed(speed)
    }

    fun select(pkg: String) { selectedPkg = pkg }

    fun outputs(): List<AudioOutputDevice> {
        val list = audio.getDevices(AudioManager.GET_DEVICES_OUTPUTS).mapNotNull { d ->
            val named: Pair<String, String> = when (d.type) {
                AudioDeviceInfo.TYPE_BUILTIN_SPEAKER -> "Phone speaker" to "speaker"
                AudioDeviceInfo.TYPE_BLUETOOTH_A2DP, AudioDeviceInfo.TYPE_BLUETOOTH_SCO ->
                    (d.productName?.toString() ?: "Bluetooth") to "headphones"
                AudioDeviceInfo.TYPE_WIRED_HEADPHONES, AudioDeviceInfo.TYPE_WIRED_HEADSET -> "Wired headphones" to "headphones"
                AudioDeviceInfo.TYPE_USB_HEADSET, AudioDeviceInfo.TYPE_USB_DEVICE -> "USB audio" to "headphones"
                AudioDeviceInfo.TYPE_HDMI -> "HDMI" to "tv"
                else -> return@mapNotNull null
            }
            AudioOutputDevice("${d.type}_${d.id}", named.first, "Connected output", false, named.second)
        }.distinctBy { it.name }
        return list.mapIndexed { i, d -> d.copy(isConnected = i == 0) }
    }
}
