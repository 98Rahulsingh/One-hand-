package com.example.system

import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import androidx.compose.ui.graphics.asImageBitmap
import androidx.core.graphics.drawable.toBitmap
import com.example.model.AppItem
import com.example.model.ItemType

/** Loads the phone's real launcher apps with real icons and real usage numbers. */
object AppsLoader {
    private fun groupFor(category: Int): String = when (category) {
        ApplicationInfo.CATEGORY_GAME -> "Games"
        ApplicationInfo.CATEGORY_AUDIO -> "Music"
        ApplicationInfo.CATEGORY_VIDEO -> "Video"
        ApplicationInfo.CATEGORY_IMAGE -> "Images"
        ApplicationInfo.CATEGORY_SOCIAL, ApplicationInfo.CATEGORY_NEWS -> "Social"
        ApplicationInfo.CATEGORY_PRODUCTIVITY -> "Productivity"
        else -> "Tools"
    }

    private fun usage(ctx: Context): Map<String, Pair<Long, Long>> = try {
        val usm = ctx.getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
        val end = System.currentTimeMillis()
        (usm.queryUsageStats(UsageStatsManager.INTERVAL_DAILY, end - 7 * 86_400_000L, end) ?: emptyList())
            .groupBy { it.packageName }
            .mapValues { e -> e.value.sumOf { it.totalTimeInForeground } to e.value.maxOf { it.lastTimeUsed } }
    } catch (e: Exception) { emptyMap() }

    fun load(ctx: Context): List<AppItem> {
        val pm = ctx.packageManager
        val u = usage(ctx)
        val q = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        return pm.queryIntentActivities(q, 0)
            .distinctBy { it.activityInfo.packageName }
            .filter { it.activityInfo.packageName != ctx.packageName }
            .map { ri ->
                val pkg = ri.activityInfo.packageName
                val bmp = try { ri.loadIcon(pm).toBitmap(96, 96).asImageBitmap() } catch (e: Throwable) { null }
                AppItem(
                    id = "app_$pkg",
                    name = ri.loadLabel(pm).toString(),
                    packageName = pkg,
                    type = ItemType.APP,
                    categoryName = groupFor(ri.activityInfo.applicationInfo.category),
                    iconName = "apps",
                    iconColor = 0xFF00BCD4,
                    isAdded = true,
                    subtitle = "",
                    usageCount = ((u[pkg]?.first ?: 0L) / 60_000L).toInt(),
                    icon = bmp,
                    lastUsed = u[pkg]?.second ?: 0L
                )
            }
            .sortedBy { it.name.lowercase() }
    }
}
