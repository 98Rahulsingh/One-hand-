package com.example.system

import android.content.Context
import android.content.pm.PackageManager
import rikka.shizuku.Shizuku

/** Runs shell commands (Wi-Fi, Bluetooth, data, airplane, floating windows) through Shizuku. */
class ShellRunner(private val ctx: Context) {
    fun isRunning(): Boolean = try { Shizuku.pingBinder() } catch (_: Throwable) { false }

    fun isReady(): Boolean = try {
        isRunning() && Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
    } catch (_: Throwable) {
        false
    }

    /** Asks Shizuku for access. Returns a short message for the user. */
    fun requestPermission(): String = try {
        when {
            !isRunning() -> "Start the Shizuku app first (Start via Wireless debugging), then try again"
            Shizuku.shouldShowRequestPermissionRationale() -> "Shizuku access was denied. Allow this app inside the Shizuku app"
            else -> { Shizuku.requestPermission(4711); "Tap Allow in the Shizuku popup" }
        }
    } catch (e: Throwable) {
        "Shizuku is not available: ${e.message}"
    }

    /** Runs one command as the shell user. Returns its output, or null if it could not run. */
    fun run(cmd: String): String? {
        if (!isReady()) return null
        return try {
            val m = Shizuku::class.java.getDeclaredMethod(
                "newProcess", Array<String>::class.java, Array<String>::class.java, String::class.java
            )
            m.isAccessible = true
            val p = m.invoke(null, arrayOf("sh", "-c", cmd), null, null) as Process
            val out = p.inputStream.bufferedReader().readText() + p.errorStream.bufferedReader().readText()
            p.waitFor()
            out.trim()
        } catch (_: Throwable) {
            null
        }
    }
}
