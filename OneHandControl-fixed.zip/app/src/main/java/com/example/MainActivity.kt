package com.example

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import com.example.model.ActiveWindow
import com.example.ui.OneHandApp
import com.example.ui.theme.MyApplicationTheme
import com.example.viewmodel.OneHandViewModel

class MainActivity : ComponentActivity() {
  // One shared ViewModel for this screen and the overlay
  private val viewModel: OneHandViewModel get() = (application as OneHandApplication).viewModel

  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge()
    handleIntent(intent)
    setContent {
      MyApplicationTheme(darkTheme = true) {
        Surface(
          modifier = Modifier.fillMaxSize(),
          color = Color(0xFF07191C)
        ) {
          OneHandApp(viewModel = viewModel)
        }
      }
    }
  }

  override fun onNewIntent(intent: Intent) {
    super.onNewIntent(intent)
    setIntent(intent)
    handleIntent(intent)
  }

  override fun onStart() {
    super.onStart()
    viewModel.setActivityVisible(true)
  }

  // Opening the app goes straight to the side panel, in its last position and size
  override fun onResume() {
    super.onResume()
    viewModel.togglePanel(true)
    viewModel.refreshPermissions()
    viewModel.refreshQuickStates()
  }

  override fun onStop() {
    super.onStop()
    viewModel.setActivityVisible(false)
    viewModel.navigateTo(ActiveWindow.MAIN_PANEL)
    viewModel.togglePanel(false)
  }

  // Quick Settings tile opens the settings window
  private fun handleIntent(i: Intent?) {
    if (i?.getBooleanExtra("open_settings", false) == true) {
      viewModel.navigateTo(ActiveWindow.PANEL_SETTINGS)
    }
  }
}
