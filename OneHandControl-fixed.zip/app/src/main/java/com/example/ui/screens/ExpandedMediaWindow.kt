package com.example.ui.screens

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Cast
import androidx.compose.material.icons.filled.DirectionsCar
import androidx.compose.material.icons.filled.Forward10
import androidx.compose.material.icons.filled.Headphones
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Repeat
import androidx.compose.material.icons.filled.RepeatOne
import androidx.compose.material.icons.filled.Replay10
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Shuffle
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.SkipPrevious
import androidx.compose.material.icons.filled.Speaker
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.ActiveWindow
import com.example.model.AudioOutputDevice
import com.example.model.MediaStreamItem
import com.example.ui.components.FloatingWindowCard
import com.example.viewmodel.OneHandViewModel

@Composable
fun ExpandedMediaWindow(
    viewModel: OneHandViewModel,
    modifier: Modifier = Modifier
) {
    val mediaState by viewModel.mediaState.collectAsState()
    val panelSettings by viewModel.panelSettings.collectAsState()
    var streamSearchQuery by remember { mutableStateOf("") }

    val filteredStreams = remember(mediaState.activeStreams, streamSearchQuery) {
        if (streamSearchQuery.isBlank()) {
            mediaState.activeStreams
        } else {
            mediaState.activeStreams.filter {
                it.trackTitle.contains(streamSearchQuery, ignoreCase = true) ||
                it.appName.contains(streamSearchQuery, ignoreCase = true) ||
                it.artist.contains(streamSearchQuery, ignoreCase = true)
            }
        }
    }

    FloatingWindowCard(
        title = "Media Center",
        initialGeometry = panelSettings.mediaWindowGeometry,
        onGeometryChange = { x, y, w, h ->
            viewModel.updateMediaWindowGeometry(x, y, w, h)
        },
        onClose = { viewModel.navigateTo(ActiveWindow.MAIN_PANEL) },
        modifier = modifier
    ) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 14.dp, vertical = 6.dp)
        ) {
            item {
                // Media permissions: tap to switch right here
                val mediaOn = panelSettings.mediaControlsEnabled
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 6.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .background(Color(0xFF0F2B32))
                        .clickable { viewModel.togglePermission("media_controls") }
                        .padding(horizontal = 10.dp, vertical = 9.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = if (mediaOn) "Media access: ON" else "Media access: OFF (tap to turn on)",
                        color = if (mediaOn) Color(0xFF80DEEA) else Color(0xFFFFD54F),
                        fontSize = 12.sp
                    )
                    Text(
                        text = if (panelSettings.writeSettingsEnabled) "Brightness: ON" else "Brightness: OFF",
                        color = if (panelSettings.writeSettingsEnabled) Color(0xFF80DEEA) else Color(0xFF9CA3AF),
                        fontSize = 11.sp
                    )
                }
            }
            item {
                // Now Playing Mini Visualizer Card
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(115.dp),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF0F2B32)),
                    border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF1F515C))
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(
                                Brush.linearGradient(
                                    colors = listOf(Color(0xFF10363F), Color(0xFF061B1E))
                                )
                            )
                            .padding(12.dp)
                    ) {
                        Column(
                            modifier = Modifier.fillMaxSize(),
                            verticalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "NOW PLAYING",
                                    color = Color(0xFF00E5FF),
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                AnimatedWaveformBar(isPlaying = mediaState.isPlaying)
                            }

                            Column {
                                Text(
                                    text = mediaState.trackTitle,
                                    color = Color(0xFFE0F7FA),
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Bold,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Text(
                                    text = mediaState.artist,
                                    color = Color(0xFF80DEEA),
                                    fontSize = 11.sp
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Precision Seek Bar
                val curMin = mediaState.currentSeconds / 60
                val curSec = mediaState.currentSeconds % 60
                val totMin = mediaState.totalSeconds / 60
                val totSec = mediaState.totalSeconds % 60

                Slider(
                    value = mediaState.currentSeconds.toFloat(),
                    onValueChange = { viewModel.seekMedia(it.toInt()) },
                    valueRange = 0f..mediaState.totalSeconds.toFloat(),
                    colors = SliderDefaults.colors(
                        thumbColor = Color(0xFF00E5FF),
                        activeTrackColor = Color(0xFF00E5FF),
                        inactiveTrackColor = Color(0xFF143B43)
                    ),
                    modifier = Modifier.fillMaxWidth().height(24.dp)
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = String.format("%02d:%02d", curMin, curSec),
                        color = Color(0xFF80DEEA),
                        fontSize = 10.sp
                    )
                    Text(
                        text = String.format("%02d:%02d", totMin, totSec),
                        color = Color(0xFF80DEEA).copy(alpha = 0.7f),
                        fontSize = 10.sp
                    )
                }

                Spacer(modifier = Modifier.height(6.dp))

                // Playback Controls
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceEvenly,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = { viewModel.toggleShuffle() }) {
                        Icon(imageVector = Icons.Default.Shuffle, contentDescription = "Shuffle", tint = if (mediaState.isShuffle) Color(0xFF00E5FF) else Color(0xFF4C757E), modifier = Modifier.size(18.dp))
                    }
                    IconButton(onClick = { viewModel.previousVideo() }) {
                        Icon(imageVector = Icons.Default.SkipPrevious, contentDescription = "Prev", tint = Color(0xFFE0F7FA), modifier = Modifier.size(22.dp))
                    }
                    IconButton(onClick = { viewModel.skipBackward15() }) {
                        Icon(imageVector = Icons.Default.Replay10, contentDescription = "-15s", tint = Color(0xFF80DEEA), modifier = Modifier.size(20.dp))
                    }
                    Box(
                        modifier = Modifier
                            .size(46.dp)
                            .shadow(8.dp, CircleShape)
                            .clip(CircleShape)
                            .background(Color(0xFF00E5FF))
                            .clickable { viewModel.togglePlayPause() },
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = if (mediaState.isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                            contentDescription = "Play/Pause",
                            tint = Color(0xFF00363A),
                            modifier = Modifier.size(26.dp)
                        )
                    }
                    IconButton(onClick = { viewModel.skipForward15() }) {
                        Icon(imageVector = Icons.Default.Forward10, contentDescription = "+15s", tint = Color(0xFF80DEEA), modifier = Modifier.size(20.dp))
                    }
                    IconButton(onClick = { viewModel.nextVideoOrChapter() }) {
                        Icon(imageVector = Icons.Default.SkipNext, contentDescription = "Next", tint = Color(0xFFE0F7FA), modifier = Modifier.size(22.dp))
                    }
                    IconButton(onClick = { viewModel.toggleRepeat() }) {
                        Icon(imageVector = if (mediaState.isRepeat) Icons.Default.RepeatOne else Icons.Default.Repeat, contentDescription = "Repeat", tint = if (mediaState.isRepeat) Color(0xFF00E5FF) else Color(0xFF4C757E), modifier = Modifier.size(18.dp))
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Playback Speed Chips
                Row(
                    modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    val speeds = listOf(0.5f, 0.75f, 1.0f, 1.25f, 1.5f, 2.0f)
                    speeds.forEach { speed ->
                        val isSelected = mediaState.playbackSpeed == speed
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .background(if (isSelected) Color(0xFF00E5FF) else Color(0xFF13363D))
                                .clickable { viewModel.setPlaybackSpeed(speed) }
                                .padding(horizontal = 9.dp, vertical = 4.dp)
                        ) {
                            Text(
                                text = "${speed}x",
                                fontSize = 10.sp,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                color = if (isSelected) Color(0xFF00363A) else Color(0xFF80DEEA)
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // ==========================================
                // Active Media Scanner & Switcher
                // ==========================================
                Text(
                    text = "ACTIVE MEDIA STREAMS (${mediaState.activeStreams.size})",
                    color = Color(0xFF00E5FF),
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.sp
                )

                Spacer(modifier = Modifier.height(6.dp))

                OutlinedTextField(
                    value = streamSearchQuery,
                    onValueChange = { streamSearchQuery = it },
                    placeholder = { Text("Search media streams...", color = Color(0xFF547B83), fontSize = 11.sp) },
                    leadingIcon = {
                        Icon(imageVector = Icons.Default.Search, contentDescription = "Search", tint = Color(0xFF00E5FF), modifier = Modifier.size(16.dp))
                    },
                    modifier = Modifier.fillMaxWidth().height(44.dp),
                    shape = RoundedCornerShape(10.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = Color(0xFF00E5FF),
                        unfocusedBorderColor = Color(0xFF163E47),
                        focusedContainerColor = Color(0xFF0C242A),
                        unfocusedContainerColor = Color(0xFF0C242A),
                        focusedTextColor = Color(0xFFE0F7FA),
                        unfocusedTextColor = Color(0xFFE0F7FA)
                    ),
                    singleLine = true
                )

                Spacer(modifier = Modifier.height(8.dp))
            }

            // Stream items
            items(filteredStreams, key = { it.id }) { stream ->
                ActiveMediaStreamCard(
                    stream = stream,
                    onSwitch = { viewModel.switchActiveMedia(stream.id) }
                )
                Spacer(modifier = Modifier.height(6.dp))
            }

            // ==========================================
            // USER SPECIFIED: "Audio output ko niche leja sabse niche"
            // Placed at the very bottom!
            // ==========================================
            item {
                Spacer(modifier = Modifier.height(14.dp))
                Text(
                    text = "AUDIO OUTPUT ROUTING",
                    color = Color(0xFF00E5FF),
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.sp
                )
                Spacer(modifier = Modifier.height(6.dp))

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    mediaState.outputDevices.forEach { device ->
                        AudioDeviceCard(
                            device = device,
                            isSelected = device.id == mediaState.selectedDeviceId,
                            onClick = { viewModel.selectAudioDevice(device.id) }
                        )
                    }
                }
                Spacer(modifier = Modifier.height(24.dp))
            }
        }
    }
}

@Composable
fun AudioDeviceCard(
    device: AudioOutputDevice,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .width(120.dp)
            .clickable { onClick() }
            .testTag("audio_device_${device.id}"),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (isSelected) Color(0xFF0E3841) else Color(0xFF0C2227)
        ),
        border = androidx.compose.foundation.BorderStroke(
            1.dp,
            if (isSelected) Color(0xFF00E5FF) else Color(0xFF163B44)
        )
    ) {
        Column(modifier = Modifier.padding(8.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = when (device.iconName) {
                        "headphones" -> Icons.Default.Headphones
                        "car" -> Icons.Default.DirectionsCar
                        "tv" -> Icons.Default.Cast
                        else -> Icons.Default.Speaker
                    },
                    contentDescription = device.name,
                    tint = if (isSelected) Color(0xFF00E5FF) else Color(0xFF80DEEA),
                    modifier = Modifier.size(18.dp)
                )

                if (isSelected) {
                    Box(
                        modifier = Modifier
                            .size(6.dp)
                            .clip(CircleShape)
                            .background(Color(0xFF00E5FF))
                    )
                }
            }

            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = device.name,
                color = Color(0xFFE0F7FA),
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Text(
                text = if (isSelected) "Active" else device.typeName,
                color = if (isSelected) Color(0xFF00E5FF) else Color(0xFF5A808A),
                fontSize = 8.sp
            )
        }
    }
}

@Composable
fun ActiveMediaStreamCard(
    stream: MediaStreamItem,
    onSwitch: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (stream.isActive) Color(0xFF0E3841) else Color(0xFF0B2126)
        ),
        border = androidx.compose.foundation.BorderStroke(
            1.dp,
            if (stream.isActive) Color(0xFF00E5FF) else Color(0xFF173F48)
        )
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(10.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                modifier = Modifier.weight(1f),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(34.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(if (stream.isActive) Color(0xFF00E5FF).copy(alpha = 0.2f) else Color(0xFF14353D)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.MusicNote,
                        contentDescription = stream.appName,
                        tint = if (stream.isActive) Color(0xFF00E5FF) else Color(0xFF80DEEA),
                        modifier = Modifier.size(18.dp)
                    )
                }

                Spacer(modifier = Modifier.width(8.dp))

                Column {
                    Text(
                        text = stream.trackTitle,
                        color = Color(0xFFE0F7FA),
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        text = "${stream.appName} • ${stream.artist} (${stream.durationText})",
                        color = Color(0xFF80DEEA).copy(alpha = 0.8f),
                        fontSize = 10.sp
                    )
                }
            }

            Spacer(modifier = Modifier.width(8.dp))

            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(10.dp))
                    .background(if (stream.isActive) Color(0xFF00E5FF) else Color(0xFF17454F))
                    .clickable { onSwitch() }
                    .padding(horizontal = 10.dp, vertical = 5.dp)
                    .testTag("switch_stream_${stream.id}"),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = if (stream.isActive) "ACTIVE" else "SWITCH",
                    color = if (stream.isActive) Color(0xFF00363A) else Color(0xFF00E5FF),
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

@Composable
fun AnimatedWaveformBar(isPlaying: Boolean) {
    val infiniteTransition = rememberInfiniteTransition(label = "waveform")
    val h1 by infiniteTransition.animateFloat(
        initialValue = 4f,
        targetValue = 18f,
        animationSpec = infiniteRepeatable(tween(400, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "h1"
    )
    val h2 by infiniteTransition.animateFloat(
        initialValue = 14f,
        targetValue = 6f,
        animationSpec = infiniteRepeatable(tween(550, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "h2"
    )
    val h3 by infiniteTransition.animateFloat(
        initialValue = 8f,
        targetValue = 20f,
        animationSpec = infiniteRepeatable(tween(350, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "h3"
    )

    Row(
        horizontalArrangement = Arrangement.spacedBy(2.dp),
        verticalAlignment = Alignment.Bottom,
        modifier = Modifier.height(20.dp)
    ) {
        val heights = if (isPlaying) listOf(h1, h2, h3) else listOf(6f, 10f, 6f)
        heights.forEach { h ->
            Box(
                modifier = Modifier
                    .width(3.dp)
                    .height(h.dp)
                    .clip(RoundedCornerShape(2.dp))
                    .background(Color(0xFF00E5FF))
            )
        }
    }
}

